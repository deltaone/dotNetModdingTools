using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle ("Mono.Cecil.Tests")]

[assembly: Guid ("da96c202-696a-457e-89af-5fa74e6bda0d")]
